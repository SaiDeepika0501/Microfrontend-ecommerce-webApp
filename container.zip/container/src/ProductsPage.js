export default function ProductsPage() {
  return <h2>🛍️ Welcome to the Products Page</h2>;
}
