import React, { useState, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AuthWrapper from './components/AuthWrapper';
import ProductsPage from './components/ProductsPage'; // Your dummy component

export default function App() {
  const [isSignedIn, setIsSignedIn] = useState(false);

  return (
    <BrowserRouter>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route
            path="/auth"
            element={<AuthWrapper onSignIn={() => {
              console.log('📌 onSignIn called from container');
              setIsSignedIn(true); // ✅ trigger render of Products
            }} />}
          />
          <Route
            path="/products"
            element={
              isSignedIn ? (
                <ProductsPage />
              ) : (
                <Navigate to="/auth" />
              )
            }
          />
          <Route
            path="/"
            element={
              isSignedIn ? <Navigate to="/products" /> : <Navigate to="/auth" />
            }
          />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
